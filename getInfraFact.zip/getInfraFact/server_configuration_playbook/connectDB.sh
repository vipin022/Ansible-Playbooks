#!/bin/bash

set -x
echo "Script Execution Started"
echo "$@"
udi=SMADMIN_READ
pwd=Readonly123
#pwd=d9cee9f07a0863947d3b02d90e108591
dbschema=HPSM2U
port=1534
server=VHKDLD749
CREATED_ON=`date '+%F %T'`
DB_Connectivitytest(){
	echo "exit" | $ORACLE_HOME/bin/sqlplus -L ${udi}/${pwd}@${server}:${port}/${dbschema}.world | grep -q "Connected to:" >/dev/null
  
	if [ $? -eq 0 ]
		then
    			echo "Connection Successful"
			DB_STATUS="UP"
		else
    			echo "unable to connect"
			DB_STATUS="Down"
		fi
}

run_sqlScript(){
echo "Checking DB connicitivity"
DB_Connectivitytest


if [[ "DB_STATUS" == "Down" ]];
then
	echo "unable to connect to database"
	exit
fi

while read line
do
echo $line > content.txt

while IFS=# read -ra arr; do
        HOST="${arr[0]##*:}"
        NODE_MODEL="${arr[1]##*:}"
	CPU_COUNT="${arr[2]##*:}"
	CPU_SPEED="${arr[3]##*:}"
	CPU_TYPE="${arr[4]##*:}"
	CPUCORE_COUNT="${arr[5]##*:}"
	IP_ADDRESS="${arr[6]##*:}"
        MEMORY_SIZE="${arr[7]##*:}"
	CPU="${arr[8]##*:}"
	OS_FAMILY="${arr[9]##*:}"
	OS_DESCRIPTION="${arr[10]##*:}"
        PATCH_LEVEL="${arr[11]##*:}"
        MACADDRESS="${arr[12]##*%}"
        #CREATED_ON="${arr[12]##*:}"

$ORACLE_HOME/bin/sqlplus ${udi}/${pwd}@${server}:${port}/${dbschema}.world<<ENDOFSQL
whenever sqlerror exit sql.sqlcode;

INSERT INTO smadmin.devicetestm1 (LOGICAL_NAME, ISTATUS, SERIAL_NO_, ASSET_TAG, CLUTERING, CPU_COUNT, CPU_TYPE, CPU_SPEED, CPUCORE_COUNT, HARDWARE_CLASS, HARDWARE_MAKE, HARDWARE_LEVEL, HARDWARE_TYPE, HARDWARE_MODEL, ILO_IP, BACKUP_IP, IP_ADDRESS, MEMORY_SIZE, NETWORK_NAME, OS_FAMILY, OS_LEVEL, OS_DESCRIPTION, ALLOCATION_STORAGE, STORAGE_TYPE, SM_LEVEL, CYBERARK, MAC_ADDRESS) VALUES ( UPPER('$HOST'),'', '$NODE_MODEL', '', '', '$CPU_COUNT', '$CPU_TYPE', '$CPU_SPEED', '$CPUCORE_COUNT', '', '', '', '', '', '', '', '$IP_ADDRESS', '$MEMORY_SIZE', '',  '$OS_FAMILY', '$PATCH_LEVEL', '$OS_DESCRIPTION', '', '', '', '', '$MACADDRESS');



exit;
ENDOFSQL
	
done < content.txt 
done < servercontent.txt
  
}
run_sqlScript
