#!/bin/bash
echo "Script Execution Started"
echo "$@"
udi=CRDD3
pwd=crd123d3data
dbschema=vklnld971
port=1540
server=trdflwd2.world
CREATED_ON= date '+t +d' 
DB_Connectivitytest(){
	echo "exit" | $ORACLE_HOME/bin/sqlplus -L ${udi}/${pwd}@${dbschema}:${port}/${server} | grep -q "Connected to:" >/dev/null
  
	if [ $? -eq 0 ]
		then
    			echo "Connection Successful"
			DB_STATUS="UP"
		else
    			echo "unable to connect"
			DB_STATUS="Down"
		fi
}
run_sqlScript(){
echo "Checking DB connicitivity"
DB_Connectivitytest


if [[ "DB_STATUS" == "Down" ]];
then
	echo "unable to connect to database"
	exit
fi

while read line
do
echo $line > content.txt

while IFS=# read -ra arr; do
        HOST="${arr[0]##*:}" 
        NODE_MODEL="${arr[1]##*:}"
	CPU_COUNT="${arr[2]##*:}"
	CPU_SPEED="${arr[3]##*:}"
	CPUCORE_COUNT="${arr[4]##*:}"
	IP_ADDRESS="${arr[5]##*:}"
        MEMORY_SIZE="${arr[6]##*:}"
	CPU="${arr[7]##*:}"
	OS_FAMILY="${arr[8]##*:}"
	OS_DESCRIPTION="${arr[9]##*:}"
        PATCH_LEVEL="${arr[10]##*:}"
        MACADDRESS="${arr[11]##*%}"
        CREATED_ON="${arr[12]##*:}"
$ORACLE_HOME/bin/sqlplus ${udi}/${pwd}@${dbschema}:${port}/${server}<<ENDOFSQL
whenever sqlerror exit sql.sqlcode;

INSERT INTO SERVERFACT (HOST, NODEMODEL, SERIAL_NO, CLUSTERING, CPU_COUNT, CPU_SPEED, CPU_TYPE, CPUCORE_COUNT, ILO_IP, BACKUP_IP, IP_ADDRESS, MEMORY_SIZE, OS_FAMILY, OS_LEVEL, OS_DESCRIPTION, PATCH_LEVEL, MACADDRESS, UPDATED_BY, CREATED_ON) VALUES ('$HOST', '$NODE_MODEL', 'blank', 'blank', '$CPU_COUNT', '$CPU_SPEED', 'blank', '$CPUCORE_COUNT', 'blank', 'blank', '$IP_ADDRESS', '$MEMORY_SIZE', '$OS_FAMILY', 'blank', '$OS_DESCRIPTION', '$PATCH_LEVEL', '$MACADDRESS', 'vipin', TO_DATE('2017-06-07 11:11:11', 'yyyy-mm-dd hh24:mi:ss'));

exit;
ENDOFSQL
	
done < content.txt 
done < servercontent.txt

  
}
run_sqlScript
