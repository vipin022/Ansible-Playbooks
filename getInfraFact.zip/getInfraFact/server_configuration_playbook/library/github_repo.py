#!/usr/bin/python
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
#from ansible.module_utils.basic import *
import os
from ansible.module_utils.basic import *
try:
    import cx_Oracle
except ImportError:
    cx_oracle_exists = False
else:
    cx_oracle_exists = True

def main():
    
    msg = ['']
    
    module = AnsibleModule(
             argument_spec = dict(
             database_uid=dict(required=True, type='str'),
             login_pwd=dict(default=None),
             login_schima=dict(default=None),
             login_port=dict(default=None),
             login_server=dict(default=None)
            #query_string=dict(default=None),
       ) ,
        
        supports_check_mode=False

    )
    
    
    user = module.params['database_uid']
    password = module.params['login_pwd']
    schima = module.params['login_schima']
    port = module.params['login_port']
    hostname = module.params['login_server']
    #sql=module.params['query_string']
    
    host = hostname + ":" + port 
    world = "world"
    if not cx_oracle_exists:
        msg[0] = "The cx_Oracle module is required. 'pip install cx_Oracle' should do the trick. If cx_Oracle is installed, make sure ORACLE_HOME & LD_LIBRARY_PATH is set"
        module.fail_json(msg=msg[0])
    
    conn_str = user + "/" + password + "@" + host + "/" + schima + "." + world
    try:
        con = cx_Oracle.connect(conn_str)
        if (con):
            print ("Connection Successful")
            print con.version
	    module.exit_json(change=True, msg= "connection successful")	
        else:
            print ("unable to connect")
	
        cursor = con.cursor()
        #querystring = "select * from table"
        #cursor.execute(sql)
        #result = (cursor.fetchall())
    except cx_Oracle.DatabaseError, e:
        error, = e
	print "error:", error.code
	print "message:", error.message
        msg[0] = 'Something went wrong while connectiing to database : %s'
        module.fail_json(msg=msg[0], change=False)
        return False
    #return result

        


if __name__ == "__main__":
    main()
    
