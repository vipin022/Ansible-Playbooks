#!/usr/bin/python

import cx_Oracle
con = cx_Oracle.connect('SMADMIN_READ/Readonly123@HPSM2U')
print con.version
con.close()

